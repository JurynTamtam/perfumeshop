<?php
session_start();
include_once "connect.php";

// Check if admin is logged in
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

$cartID = $_GET['cartID'];

// Delete cart items
$sql_delete_cart_items = "DELETE FROM cart_items WHERE cartID = $cartID";
$stmt = $con->prepare($sql_delete_cart_items);
$stmt->bind_param("i", $cartID);
$stmt->execute();
$stmt->close();

// Delete cart
$sql_delete_cart = "DELETE FROM carts WHERE cartID = $cartID";
$stmt = $con->prepare($sql_delete_cart); // Corrected this line
$stmt->bind_param("i", $cartID);
$stmt->execute();
$stmt->close();

header("Location: admin_manage_carts.php");
exit();
?>

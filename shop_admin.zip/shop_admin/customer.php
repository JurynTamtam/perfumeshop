<?php
include_once "connect.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Customers</title>
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <header align="center">
        <h2>Manage Customers</h2>
        <p>Submitted by: Lastname, Firstname MI</p>
    </header>
    <div align="center" class="container">
        <a align="right" href="save.php" class="btn btn-outline-primary mb-2">Add Customer</a>
        <table border="1" width="75%" class="table table-hover table-bordered">
            <tr>
                <th>ID</th>
                <th>Customer Name</th>
                <th>Contact Name</th>
                <th>Address</th>
                <th>City</th>
                <th>Postal Code</th>
                <th>Username</th>
                <th>Password</th>
                <th>Action</th>
            </tr>
<?php
    $sql_customer = "SELECT * FROM tbl_customer";
    $result_customer = mysqli_query($con, $sql_customer);

    if (mysqli_num_rows($result_customer) > 0) {
        while($row = mysqli_fetch_array($result_customer)) {
            echo "<tr>";
                echo "<td>".$row['CustomerID']."</td>";
                echo "<td>".$row['CustomerName']."</td>";
                echo "<td>".$row['ContactName']."</td>";
                echo "<td>".$row['Address']."</td>";
                echo "<td>".$row['City']."</td>";
                echo "<td>".$row['PostalCode']."</td>";
                echo "<td>".$row['username']."</td>";
                echo "<td>".$row['password']."</td>";
                echo "<td>".$row['Country']."</td>";
                echo "<td>";
                    echo "<a href='update.php?id=".$row['CustomerID']."' class='btn btn-outline-warning'>Edit</a>";
                    echo " <a href='delete.php?id=".$row['CustomerID']."' class='btn btn-outline-danger'>Delete</a>";
                echo "</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='8'>No records found</td></tr>";
    }
?>
        </table>
    </div>
</body>
</html>

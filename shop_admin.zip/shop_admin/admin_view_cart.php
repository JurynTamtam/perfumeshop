<?php
session_start();
include_once "connect.php";

$cartID = $_GET['cartID'];

// Fetch cart items
$sql_cart_items = "SELECT product.productname, product.price, cart_items.quantity 
                   FROM cart_items 
                   JOIN product ON cart_items.productID = product.productID 
                   WHERE cart_items.cartID = ?";
$stmt = $con->prepare($sql_cart_items);
$stmt->bind_param("i", $cartID);
$stmt->execute();
$result_cart_items = $stmt->get_result();
$stmt->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin - View Cart</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2>View Cart</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Product Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = mysqli_fetch_assoc($result_cart_items)) {
                    echo "<tr>
                            <td>{$row['productname']}</td>
                            <td>{$row['price']}</td>
                            <td>{$row['quantity']}</td>
                          </tr>";
                }
                ?>
            </tbody>
        </table>
        <a href="#" class="btn btn-primary" onclick="window.history.back();">close</a>
    </div>
</body>
</html>

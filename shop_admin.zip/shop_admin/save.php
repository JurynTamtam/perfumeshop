<!DOCTYPE html>
<html>
<head>
	<title>Customer Registration</title>
</head>
<body align="center">
		<h2>Customer Registration form</h2>
         <div >
          <form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
		        <input type="text" placeholder="Enter customer name" name="CustomerName" required><br><br>
		        <input type="text" placeholder="Enter contact name" name="ContactName" required><br><br>
		        <input type="text" placeholder="Enter address" name="Address" required><br><br>
		        <input type="text" placeholder="Enter city" name="City" required><br><br>
		        <input type="text" placeholder="Enter postal code" name="PostalCode" required><br><br>
		        <input type="text" placeholder="Enter country" name="Country" required><br><br>
				<input type="text" placeholder="Enter username" name="username" required><br><br>
		        <input type="text" placeholder="Enter password" name="password" required><br><br>
		     	<input class="btn btn-success" type="submit">

		  </form>
      </div>
</body>
</html>




<?php
include_once "connect.php";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // collect value of input field
  $CustomerName = $_REQUEST['CustomerName'];
  $ContactName = $_REQUEST['ContactName'];
  $Address = $_REQUEST['Address'];
  $City = $_REQUEST['City'];
  $PostalCode = $_REQUEST['PostalCode'];
  $Country = $_REQUEST['Country'];
  $username = $_REQUEST['username'];
  $password = $_REQUEST['password'];
  $sql = "INSERT INTO tbl_customer (CustomerName,ContactName,Address,City,PostalCode,Country, username, password)
         VALUES('$CustomerName','$ContactName','$Address','$City','$PostalCode','$Country','$username','$password')";

	if ($con->query($sql) === TRUE) {
	  echo "New record created successfully";
	  header('location:index.php');
	} else {
	  echo "Error: " . $sql . "<br>" . $con->error;
	}

	$con->close();
}
?>
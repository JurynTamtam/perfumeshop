<?php
include_once "connect.php";



// Fetch all carts
$sql_carts = "SELECT carts.cartID, tbl_customer.username, carts.created_at 
              FROM carts 
              JOIN tbl_customer ON carts.customerID = tbl_customer.customerID";
$result_carts = mysqli_query($con, $sql_carts);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin - Manage Carts</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2>Manage Customer Carts</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Cart ID</th>
                    <th>Customer Username</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = mysqli_fetch_assoc($result_carts)) {
                    echo "<tr>
                            <td>{$row['cartID']}</td>
                            <td>{$row['username']}</td>
                            <td>{$row['created_at']}</td>
                            <td>
                                <a href='admin_view_cart.php?cartID={$row['cartID']}' class='btn btn-info'>View</a>
                                <a href='admin_delete_cart.php?cartID={$row['cartID']}' class='btn btn-danger' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                            </td>
                          </tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>

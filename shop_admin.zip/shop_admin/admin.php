<?php
session_start();
include 'db_connection.php'; // Include your database connection file

// Ensure the user is an admin
if ($_SESSION['user_role'] != 'admin') {
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin - Manage Carts</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <h2>Manage Customer Carts</h2>
    <table class="table">
        <thead>
        <tr>
            <th>Cart ID</th>
            <th>User ID</th>
            <th>Product Name</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Total</th>
        </tr>
        </thead>
        <tbody>
        <?php
        // Fetch all active carts and their items
        $query = "SELECT c.cartID, c.customerID, ci.productID, ci.quantity, p.productname, p.price FROM carts c
                  JOIN cart_items ci ON c.cartID = ci.cartID
                  JOIN product p ON ci.productID = p.productID";
        $result = $con->query($query);

        if ($result->num_rows > 0) {
            while ($item = $result->fetch_assoc()) {
                ?>
                <tr>
                    <td><?php echo $item['cartID']; ?></td>
                    <td><?php echo $item['customerID']; ?></td>
                    <td><?php echo $item['productname']; ?></td>
                    <td>Php <?php echo $item['price']; ?></td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td>Php <?php echo $item['price'] * $item['quantity']; ?></td>
                </tr>
                <?php
            }
        } else {
            ?>
            <tr>
                <td colspan="6">No active carts</td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    </table>
</div>
</body>
</html>

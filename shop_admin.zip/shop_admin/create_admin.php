<?php
include_once "connect.php";

// Define admin credentials
$username = 'admin';
$password = 'admin123'; // Replace with your desired password

// Hash the password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Insert admin user into the database
$sql = "INSERT INTO admin_users (username, password) VALUES ('$username', '$hashed_password')";
if (mysqli_query($con, $sql)) {
    echo "Admin user created successfully.";
} else {
    echo "Error creating admin user: " . mysqli_error($con);
}

mysqli_close($con);
?>

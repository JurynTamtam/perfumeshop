<?php
include_once "connect.php";
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Manage Product</title>
		<!-- Latest compiled and minified CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Latest compiled JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js"></script>
	</head>
	<body>
		<br><br>
		<div align="center" class="container" >
		<button type="button" class="btn btn-primary" style="float: right;" onclick="window.location.href='add-product.php';">Add record</button>
		<table border="1" width="75%" class="table table-hover table-bordered">
			<tr>
				<th>ID</th>
				<th>Product Name</th>
				<th>Description</th>
				<th>Price</th>
				<th>Quantity</th>
				<th>Image</th>
				<th>Action</th>
					
				

			</tr>
<?php
    $sql_profile = "SELECT * FROM product ORDER BY productname";
    $result_profile = mysqli_query($con, $sql_profile);

    if (mysqli_num_rows($result_profile) > 0) {
        while($row = mysqli_fetch_array($result_profile)) {
        	echo "<tr>";
	        	echo "<td>".$row['productID']."</td>";
	        	echo "<td>".$row['productname']."</td>";
	        	echo "<td>".$row['productdescription']."</td>";
	        	echo "<td>".$row['price']."/".$row['productunit']."</td>";
	        	echo "<td>".$row['quantity']."</td>";
	        	echo "<td><img src='".$row['image_url']."' width='50px'></td>";
	        	echo "<td>";
	        		echo "<a href='update-product.php?id=".$row['productID']."' class='btn btn-outline-warning'>Edit</a>";
	        		echo " <a href='delete-product.php?id=".$row['productID']."' class='btn btn-outline-danger'>Delete</a>";
	        	echo "</td>";
        	echo "</tr>";
       }
    }
?>
		</table>
		</div>
	</body>
</html>





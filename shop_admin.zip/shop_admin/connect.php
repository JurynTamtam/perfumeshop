<?php

    $con = new mysqli("localhost","bsitrdye_juryn","onlineserverinhybrid","bsitrdye_icat");

    if ($con->connect_error) {
        die("Connection failed: " . $con->connect_error);
    }

    $con->set_charset("utf8");


 

?>
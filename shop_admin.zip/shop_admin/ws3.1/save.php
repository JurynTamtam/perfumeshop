<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body align="center">
		<h2>Registration form</h2>
         <div >
          <form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
		        <input type="text" placeholder="Enter lastname" name="lastname" required><br><br>
		        <input type="text" placeholder="Enter firstname" name="firstname" required><br><br>
		        <input type="text" placeholder="Enter middlename" name="middlename" required><br><br>
		        <input type="text" placeholder="Enter address" name="address" required><br><br>
		     	<input class="btn btn-success" type="submit">

		  </form>
      </div>
</body>
</html>


<?php
include_once "connect.php";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // collect value of input field
  $CustomerID = $_REQUEST['CustomerID'];
  $CustomerName = $_REQUEST['CustomerName'];
  $ContactName = $_REQUEST['ContactName'];
  $Address = $_REQUEST['Address'];
  $City = $_REQUEST['City'];
  $PostalCode = $_REQUEST['PostalCode'];
  $Country = $_REQUEST['Country'];
  $sql = "UPDATE tbl_customer
		SET CustomerName = '$CustomerName', ContactName = '$ContactName',Address='$Address',City='$City',PostalCode='$PostalCode',Country='$Country'
		WHERE CustomerID=$CustomerID";

	if ($con->query($sql) === TRUE) {
	  echo "New record created successfully";
	  header('location:index.php');
	} else {
	  echo "Error: " . $sql . "<br>" . $con->error;
	}

	$con->close();
}
?>
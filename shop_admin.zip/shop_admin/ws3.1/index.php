<?php
include_once "connect.php";
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Manage Profile</title>
		<!-- Latest compiled and minified CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Latest compiled JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js"></script>
	</head>
	<body>
		<header align="center">
			<h2>Manage Profile</h2>
			<p>Submitted by: Lastname, Firstname MI</p>
		</header>
		<div align="center" class="container" >
				<a  align="right" href="save.php">Add record</a>
		<table border="1" width="75%" class="table table-hover table-bordered">
			<tr>
				<th>ID</th>
				<th>Lastname</th>
				<th>Firstname</th>
				<th>Middlename</th>
				<th>Address</th>
				<th>Action</th>
			</tr>
<?php
    $sql_profile = "SELECT * FROM tbl_profile";
    $result_profile = mysqli_query($con, $sql_profile);

    if (mysqli_num_rows($result_profile) > 0) {
        while($row = mysqli_fetch_array($result_profile)) {
        	echo "<tr>";
	        	echo "<td>".$row['profileID']."</td>";
	        	echo "<td>".$row['lastname']."</td>";
	        	echo "<td>".$row['firstname']."</td>";
	        	echo "<td>".$row['middlename']."</td>";
	        	echo "<td>".$row['address']."</td>";
	        	echo "<td>";
	        		echo "<a href='update.php?id=".$row['profileID']."&ln=".$row['lastname']."&fn=".$row['firstname']."&mn=".$row['middlename']."&ad=".$row['address']."' class='btn btn-outline-warning'>Edit</a>";
	        		echo " <a href='delete.php?id=".$row['profileID']."' class='btn btn-outline-danger'>Delete</a>";
	        	echo "</td>";
        	echo "</tr>";
       }
    }
?>
		</table>
		</div>
	</body>
</html>




